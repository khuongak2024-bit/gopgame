# Võ Lâm Reset – đóng gói thành app (Android / iOS)

Thư mục này đã có sẵn game (`www/index.html`), icon và màn hình chờ (`assets/`).
Công cụ dùng: **Capacitor** – bọc trang HTML5 thành app thật.

## Cần cài trước (trên máy tính)
- Node.js bản LTS: https://nodejs.org
- Android: Android Studio – https://developer.android.com/studio
- iOS: máy Mac + Xcode (App Store của Mac)

## 1. Cài và tạo dự án
Mở Terminal / Command Prompt tại thư mục này rồi chạy:

    npm install
    npx cap add android
    npx cap add ios          (chỉ trên Mac)
    npm run assets           (tạo icon + splash cho mọi cỡ màn hình)
    npx cap sync

Muốn đổi mã định danh app thì sửa `appId` trong `capacitor.config.json` TRƯỚC bước `cap add`
(ví dụ `com.tencuaban.volamreset`; sau khi đã đưa lên cửa hàng thì không đổi được nữa).

## 2. Khoá màn hình ngang
- Android: mở `android/app/src/main/AndroidManifest.xml`, trong thẻ `<activity ...>` thêm
  `android:screenOrientation="sensorLandscape"`
- iOS: Xcode → target App → General → Device Orientation: chỉ tick Landscape Left/Right.

## 3. Chạy thử
    npm run android    → Android Studio mở ra → bấm ▶ (Run) với điện thoại cắm cáp hoặc máy ảo
    npm run ios        → Xcode mở ra → chọn iPhone → ▶

## 4. Mỗi lần cập nhật game
Chép file game mới đè lên `www/index.html`, rồi chạy `npx cap sync` và build lại.
Nhớ tăng số phiên bản (Android: versionCode/versionName trong android/app/build.gradle;
iOS: Version/Build trong Xcode).

## 5. Đưa lên Google Play
1. Đăng ký Google Play Console (phí 25 USD, trả một lần).
2. Android Studio → Build → Generate Signed Bundle → **Android App Bundle (.aab)**.
   Tạo keystore và CẤT KỸ file + mật khẩu (mất là không cập nhật app được).
3. Play Console → Tạo ứng dụng → điền thông tin, chính sách quyền riêng tư, phân loại nội dung.
4. Tài khoản cá nhân mới: phải chạy **thử nghiệm kín (closed testing) với ít nhất 12 người, liên tục 14 ngày**
   rồi mới được xin phát hành chính thức (production).
5. Gửi xét duyệt.

## 6. Đưa lên App Store
1. Đăng ký Apple Developer Program (99 USD/năm).
2. Xcode → Product → Archive → Distribute App → App Store Connect.
3. App Store Connect: tạo app, ảnh chụp màn hình, mô tả, chính sách quyền riêng tư → TestFlight để thử → gửi xét duyệt.

## Ghi chú
- Tiến trình lưu trong app (localStorage) – xoá app là mất dữ liệu.
- Game có dùng phông chữ Google (Noto Serif) cho tiêu đề; không có mạng thì tự dùng phông thay thế, game vẫn chạy.
